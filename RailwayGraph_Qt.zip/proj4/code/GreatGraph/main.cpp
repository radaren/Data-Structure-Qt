//
//  main.cpp
//  GreatGraph
//
//  Created by radar_sir on 11/12/2016.
//  Copyright © 2016 SYSU_SMIE. All rights reserved.
//
#include <iostream>
#include <fstream>
#include "Graph.hpp"
Graph railway;
ifstream fin("in.txt");
int main(int argc, const char * argv[]) {
    string fro,dst;
    int dis;
    while (fin >> fro >> dst >> dis) {
        railway.insert(fro, dst, dis);
    }
    
    do{
        cout << "出发点 : " << fro << endl;
        cout << "宽度优先搜索测试" << endl;
        railway.bfs(fro);
        railway.init();
        cout << endl << endl;
        cout << "名称(访问次序)" << endl;
        TreeNode *now = railway.bfsT(fro);
        railway.ptree(now);
        railway.init();
        cout << endl;
        cout << "广度优先搜索测试" << endl;
        railway.dfs_nonres(fro);
        railway.init();
        cout << endl << endl;
        cout << "名称(访问次序)" << endl;
        now = railway.dfsT(fro);
        railway.ptree(now);
        railway.init();
        cout << endl;
    }while (cin >> fro);
    
    return 0;
}
