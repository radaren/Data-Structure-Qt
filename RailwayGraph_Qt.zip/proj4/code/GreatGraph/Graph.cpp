//
//  Graph.cpp
//  GreatGraph
//
//  Created by radar_sir on 14/12/2016.
//  Copyright © 2016 SYSU_SMIE. All rights reserved.
//

#include "Graph.hpp"
Graph::Graph(){
    for (int i = 0; i < maxN; i++) {
        Heads[i] = NULL;
    }
    totid = 0;
    ID.clear();
    RID.clear();
}
int Graph::findID(string s)
{
    if (ID.count(s) == false) {
        RID[totid] = s;
        ID[s] = totid;
        totid++;
    }
    return ID[s];
}
void Graph::insert(string a, string b, int val = 0)
{
    insert(findID(a), findID(b), val);
}
void Graph::bfs(string a)
{
    bfs(findID(a));
}
void Graph::dfs(string a)
{
    dfs(findID(a));
}
void Graph::dfs_nonres(string start)
{
    dfs_nonres(findID(start));
}
TreeNode* Graph::bfsT(string a)
{
    return bfsT(findID(a));
}

TreeNode* Graph::dfsT(string a)
{
    return dfsT(findID(a));
}

void Graph::insert(int a, int b, int val = 0)
{
    Edge * nowEdge = new Edge(a,b,val);
    nowEdge->nextA = Heads[a];
    Heads[a] = nowEdge;
    nowEdge->nextB = Heads[b];
    Heads[b] = nowEdge;
}
void Graph::print(int v)
{
    if (RID.count(v)) {
        cout << RID[v];
    }else
        cout << v;
}
void Graph::printEdge(int a, int b, int val = -718)
{
    cout << "[";
    print(a);
    cout << "->";
    print(b);
    cout << "]";
    if (val != -718) {
        cout << "(" << val << ")  " << endl;
    }
}
void Graph::bfs(int start)
{
    queue<int> BFS;
    BFS.push(start);
    vis[start] = 1;
    while (BFS.size()) {
        int now = BFS.front();
        BFS.pop();
        Edge *VisAllAdjanceEdge = Heads[now];
        while (VisAllAdjanceEdge) {
            Edge * nextEdge = NULL;
            int otherVertex;
            if (VisAllAdjanceEdge->VertexAid == now) {
                nextEdge = VisAllAdjanceEdge->nextA;
                otherVertex = VisAllAdjanceEdge->VertexBid;
            }else{
                nextEdge = VisAllAdjanceEdge->nextB;
                otherVertex = VisAllAdjanceEdge->VertexAid;
            }
            if (VisAllAdjanceEdge->mark == false and !vis[otherVertex]) {
                vis[otherVertex] = 1;
                // output  next node
                BFS.push(otherVertex);
                // output edge
                printEdge(now, otherVertex,VisAllAdjanceEdge->val);
                VisAllAdjanceEdge->mark = true;
            }// never visit before
            VisAllAdjanceEdge = nextEdge;
        }
    }
    init();
}
void Graph::init()
{
    memset(vis, 0, sizeof(vis));
    
    for (int i = 0; i < maxN; i++) {
        Edge *VisAllAdjanceEdge = Heads[i];
        while(VisAllAdjanceEdge) {
            VisAllAdjanceEdge->mark = 0;
            VisAllAdjanceEdge = (VisAllAdjanceEdge->VertexAid == i)
            ?VisAllAdjanceEdge->nextA : VisAllAdjanceEdge->nextB;
        }
    }
}

void Graph::dfs(int start)
{
    Edge *VisAllAdjanceEdge = Heads[start];
    print(start);
    while (VisAllAdjanceEdge) {
        Edge * nextEdge;
        int otherVertex;
        if (VisAllAdjanceEdge->VertexAid == start) {
            nextEdge = VisAllAdjanceEdge->nextA;
            otherVertex = VisAllAdjanceEdge->VertexBid;
        }else{
            nextEdge = VisAllAdjanceEdge->nextB;
            otherVertex = VisAllAdjanceEdge->VertexAid;
        }
        if (VisAllAdjanceEdge->mark == false) {
            VisAllAdjanceEdge->mark = true;
            // output  next node
            dfs(otherVertex);
            // output edge
            printEdge(start, otherVertex,VisAllAdjanceEdge->val);
        }// never visit before
        VisAllAdjanceEdge = nextEdge;
    }
}

TreeNode* Graph::bfsT(int start)
{
    TreeNode * root = new TreeNode(start);
    queue<TreeNode*> BFS;
    BFS.push(root);
    while (BFS.size()) {
        TreeNode* now = BFS.front();
        BFS.pop();
        Edge *VisAllAdjanceEdge = Heads[now->id];
        while (VisAllAdjanceEdge) {
            Edge * nextEdge;
            int otherVertex;
            if (VisAllAdjanceEdge->VertexAid == now->id) {
                nextEdge = VisAllAdjanceEdge->nextA;
                otherVertex = VisAllAdjanceEdge->VertexBid;
            }else{
                nextEdge = VisAllAdjanceEdge->nextB;
                otherVertex = VisAllAdjanceEdge->VertexAid;
            }
            if (VisAllAdjanceEdge->mark == false) {
                // output  next node
                TreeNode * sub = new TreeNode(otherVertex);
                now->subTree.push_back(sub);
                BFS.push(sub);
                VisAllAdjanceEdge->mark = true;
            }// never visit before
            VisAllAdjanceEdge = nextEdge;
        }
    }
    return root;
}
TreeNode* Graph::dfsT(int now)
{
    TreeNode * root = new TreeNode(now);
    Edge *VisAllAdjanceEdge = Heads[now];
    while (VisAllAdjanceEdge) {
        Edge * nextEdge;
        int otherVertex;
        if (VisAllAdjanceEdge->VertexAid == now) {
            nextEdge = VisAllAdjanceEdge->nextA;
            otherVertex = VisAllAdjanceEdge->VertexBid;
        }else{
            nextEdge = VisAllAdjanceEdge->nextB;
            otherVertex = VisAllAdjanceEdge->VertexAid;
        }
        if (VisAllAdjanceEdge->mark == false) {
            VisAllAdjanceEdge->mark = true;
            // output  next node
            root->subTree.push_back(dfsT(otherVertex));
        }// never visit before
        VisAllAdjanceEdge = nextEdge;
    }
    return root;
}
void Graph::ptree(TreeNode* root)
{
    ptree(root, 0);
}
void Graph::ptree(TreeNode* root, int cen )
{
    if (root == NULL ) {
        return;
    }
    if (cen) {
        for (int i = 0; i < cen; i++) {
            putchar('\t');
        }
        putchar('|');
        putchar(' ');
    }
    print(root->id);
    cout << "(" << cen << ")";
    putchar('\n');
    for(int i = 0;i < root->subTree.size();i++)
    {
        ptree(root->subTree[i], cen+1);
    }
}
void Graph::dfs_nonres(int start)
{
    stack<int> DFS;
    DFS.push(start);
    while (DFS.size()) {
        int now = DFS.top();
        bool findsub = false;
        Edge *VisAllAdjanceEdge = Heads[now];
        while (VisAllAdjanceEdge) {
            Edge * nextEdge = NULL;
            int otherVertex;
            if (VisAllAdjanceEdge->VertexAid == now) {
                nextEdge = VisAllAdjanceEdge->nextA;
                otherVertex = VisAllAdjanceEdge->VertexBid;
            }else{
                nextEdge = VisAllAdjanceEdge->nextB;
                otherVertex = VisAllAdjanceEdge->VertexAid;
            }
            if (VisAllAdjanceEdge->mark == false) {
                // output  next node
                DFS.push(otherVertex);
                // output edge
                printEdge(now, otherVertex,VisAllAdjanceEdge->val);
                VisAllAdjanceEdge->mark = true;
                findsub = true;
                break;
            }// never visit before
            VisAllAdjanceEdge = nextEdge;
        }
        if (findsub == false) {
            DFS.pop();
        }
    }
}