//
//  Edge.hpp
//  GreatGraph
//
//  Created by radar_sir on 11/12/2016.
//  Copyright © 2016 SYSU_SMIE. All rights reserved.
//

#ifndef Edge_hpp
#define Edge_hpp

struct Edge{
    Edge(int a = 0, int b = 0, int val = 0):
    VertexAid(a),VertexBid(b),val(val),nextA(NULL),nextB(NULL){};
    int val;
    int mark;
    int VertexAid, VertexBid;
    Edge *nextA, *nextB;

};

#endif