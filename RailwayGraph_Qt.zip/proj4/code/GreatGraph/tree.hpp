//
//  tree.hpp
//  GreatGraph
//
//  Created by radar_sir on 14/12/2016.
//  Copyright © 2016 SYSU_SMIE. All rights reserved.
//

#ifndef tree_hpp
#define tree_hpp

#include <stdio.h>
#include <vector>
using namespace std;

struct TreeNode {
    int id;
    vector<TreeNode*> subTree;
    TreeNode(int id):id(id){};
    void print(){
        printTree(this, 0);
    };
    void printTree(TreeNode *v, int cen)
    {
        if(v == NULL) return;
        for(int i = 0;i < cen;i++)putchar('+');
        printf("%d",v->id);
        putchar('\n');
        for(int i = 0;i < v->subTree.size();i++)
        {
            printTree(v->subTree[i], cen+1);
        }
    }
};


#endif /* tree_hpp */
