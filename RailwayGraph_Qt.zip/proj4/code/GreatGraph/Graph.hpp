//
//  Graph.hpp
//  GreatGraph
//
//  Created by radar_sir on 14/12/2016.
//  Copyright © 2016 SYSU_SMIE. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp
#include <cstdio>
#include <map>
#include <queue>
#include <stack>
#include <iostream>
#include "Edge.hpp"
#include "tree.hpp"
using namespace std;

class Graph{
public:
    Graph();
    void insert(int, int, int);
    void insert(string, string, int);
    void init();
    void bfs(int);
    void bfs(string);
    void dfs(int);
    void dfs(string);
    TreeNode* bfsT(int);
    TreeNode* bfsT(string);
    
    TreeNode* dfsT(int);
    TreeNode* dfsT(string);
    
    void dfs_nonres(int);
    void dfs_nonres(string start);
    void ptree(TreeNode*);
private:
    void print(int);
    void ptree(TreeNode*, int );
    void printEdge(int , int ,int);
    int findID(string);
    int totid;
    map<string, int> ID;
    map<int,string> RID;
    static const int maxN = 1000;
    Edge* Heads[maxN];
    int vis[maxN];
    
};

#endif /* Graph_hpp */
